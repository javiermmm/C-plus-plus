#ifndef __CALGORITMOSOBREVECTORES_H
#define __CALGORITMOSOBREVECTORES_H

#include <string>
#include "Algoritmo.h"

class CAlgoritmoSobreVectores : public CAlgoritmo {
public:
	CAlgoritmoSobreVectores ();
	virtual  ~CAlgoritmoSobreVectores ();
	virtual std::string  getDescription ()=0 {}
	virtual void  SetUp (int N)=0 {}
	virtual void  Execute ()=0 {}
	virtual void  TearDown ();
protected:
	//_v representa el vector que vamos a ordenar
	//_valoresIniciales representa el vector inicial (que vamos a copiar)
	//_tam representa el tama�o que va a tomar el vector
	int *_v;
	int *_valoresIniciales;
	int _tam;
};



#endif