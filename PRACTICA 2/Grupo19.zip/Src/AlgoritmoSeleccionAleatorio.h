#ifndef __CALGORITMOSELECCIONALEATORIO_H
#define __CALGORITMOSELECCIONALEATORIO_H

#include "AlgoritmoSobreVectores.h"
#include "MetodosGeneracion.h"
#include "MetodosOrdenacion.h"

//Clase documentada a partir de CAlgoritmo y CAlgoritmoSobreVectores
//en los ficheros "Algoritmo.h" y "AlgoritmoSobreVectores.h"
class CAlgoritmoSeleccionAleatorio : public CAlgoritmoSobreVectores {
public:
	CAlgoritmoSeleccionAleatorio ();
	virtual  ~CAlgoritmoSeleccionAleatorio ();
	virtual std::string  getDescription ();
	virtual void  SetUp (int N);
	virtual void  Execute ();
};

#endif