#ifndef __METODOSORDENACION_H
#define __METODOSORDENACION_H

void  ordenaInsercion (int v[], int num); 
void  ordenaSeleccion (int v[], int num); 
void  ordenaBurbuja (int v[], int num); 
void  quickSort (int v[], int num); 
void  mergeSort (int v[], int num); 

#endif