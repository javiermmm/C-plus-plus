#ifndef __METODOSGENERACION_H
#define __METODOSGENERACION_H

void  generarCreciente (int v[], int num); 
void  generarDecreciente (int v[], int num); 
void  generarAleatorio (int v[], int num); 

#endif