#ifndef __CSALIDAGNUPLOT_H
#define __CSALIDAGNUPLOT_H

#include "Salida.h"

#include <string>
#include <fstream>

//M�s informaci�n en la clase CSalida en el fichero "Salida.h"
class CSalidaGNUPlot : public CSalida {
public:
	//Constructor con el nombre del fichero como par�metro
	CSalidaGNUPlot (std::string name = "");
	virtual  ~CSalidaGNUPlot ();
	virtual void  InitPrueba (const std::string &desc);
	virtual void  Muestra (int tam, float tiempo);
	virtual void  FinPrueba ();
protected:
	std::ofstream _f; //Fichero en el que se van a escribir los datos
	std::string _nombre; //nombre del fichero anterior
};

#endif