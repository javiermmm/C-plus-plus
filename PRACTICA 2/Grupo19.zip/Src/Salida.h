#ifndef __CSALIDA_H
#define __CSALIDA_H

#include <string>

//Clase para representar las posibles salidas por las que se muestra la informacion
//Es una clase abstracta con todos sus metodos virtuales puros
//de manera que se usa a modo de interfaz.
class CSalida {
public:
	//Destructor
	virtual  ~CSalida () {}

	//Funci�n que inicializa la salida
	virtual void  InitPrueba (const std::string &desc)=0 {}

	//Funci�n que muestra los resultados por la salida que sea
	virtual void  Muestra (int tam, float tiempo)=0 {}

	//Funci�n que muestra el final de los resultados
	virtual void  FinPrueba ()=0 {}
};

#endif