#include "Form1.h"

namespace Pr2WindowsForms {

//Evento en respuesta a la pulsaci�n del bot�n "Limpiar"
System::Void Form1::bLimpiar_Click(System::Object^  sender, System::EventArgs^  e) {

	tbResultados->Clear();		 
}

//Evento en respuesta a la pulsaci�n del bot�n "Comenzar Pruebas" que ejecuta
//las mediciones de tiempo, extrayendo la informaci�n de los textBox y ComboBox.
//Si dichos cuadros de datos estan vacios no se hace nada.
System::Void Form1::bComenzar_Click(System::Object^  sender, System::EventArgs^  e) {

			 //Limpiamos los resultados previos
			 tbResultados->Clear();

			 //Creamos la salida
			 CSalidaWindowsForms* salida = new CSalidaWindowsForms (this->tbResultados);

			 //Comprobamos que hay datos
			 if ((this->tbTamIni->Text != "") && (this->tbTamFin->Text != "") && (this->tbIncremento->Text != "") && (this->tbRepeticionesIni->Text != "") && (this->tbRepeticionesFin->Text != "")) {

				 //Creamos la medicion de tiempos
				 CMideTiempos* medicion = new CMideTiempos (System::Convert::ToInt32(this->tbTamIni->Text), System::Convert::ToInt32(this->tbTamFin->Text), System::Convert::ToInt32(this->tbIncremento->Text), System::Convert::ToInt32(this->tbRepeticionesIni->Text), System::Convert::ToInt32(this->tbRepeticionesFin->Text));
			 
				 CAlgoritmo* alg;
				 std::string nombre;
				 //Comprobamos que se han seleccionado algoritmo y configuraci�n de los datos
				 //y generamos el nombre del fichero en consecuencia
				 if (this->cbAlgoritmo->SelectedIndex != -1){
						 switch (this->cbAlgoritmo->SelectedIndex) {
							 //Inserci�n
							case 0: if (this->cbDatos->SelectedIndex != -1)
									 switch (this->cbDatos->SelectedIndex) { 
										 case 0: {alg = new CAlgoritmoInsercionCreciente();
												  nombre = "insercionCreciente.txt";
												  break;
												 }
										 case 1: {alg = new CAlgoritmoInsercionDecreciente();
												  nombre = "insercionDecreciente.txt";
												  break;
												 }
										 case 2: {alg = new CAlgoritmoInsercionAleatorio();
												  nombre = "insercionAleatorio.txt";
												  break;
												 }
									 }
									 break;
							//Selecci�n
							case 1: if (this->cbDatos->SelectedIndex != -1)
									 switch (this->cbDatos->SelectedIndex) { 
										 case 0: {alg = new CAlgoritmoSeleccionCreciente();
												  nombre = "seleccionCreciente.txt";
												  break;
												 }
										 case 1: {alg = new CAlgoritmoInsercionDecreciente();
												  nombre = "seleccionDecreciente.txt";
												  break;
												 }
										 case 2: {alg = new CAlgoritmoInsercionAleatorio();
												  nombre = "seleccionAleatorio.txt";
												  break;
												 }
									 }
									 break;
							//Burbuja
							case 2: if (this->cbDatos->SelectedIndex != -1)
									 switch (this->cbDatos->SelectedIndex) { 
										 case 0: {alg = new CAlgoritmoBurbujaCreciente();
												  nombre = "burbujaCreciente.txt";
												  break;
												 }
										 case 1: {alg = new CAlgoritmoBurbujaDecreciente();
												  nombre = "burbujaDecreciente.txt";
												  break;
												 }
										 case 2: {alg = new CAlgoritmoBurbujaAleatorio();
												  nombre = "burbujaAleatorio.txt";
												  break;
												 }
									 }
									 break;
							//Quicksort
							case 3: if (this->cbDatos->SelectedIndex != -1)
									 switch (this->cbDatos->SelectedIndex) { 
										 case 0: {alg = new CAlgoritmoQuicksortCreciente();
												  nombre = "quicksortCreciente.txt";
												  break;
												 }
										 case 1: {alg = new CAlgoritmoQuicksortDecreciente();
												  nombre = "quicksortDecreciente.txt";
												  break;
												 }
										 case 2: {alg = new CAlgoritmoQuicksortAleatorio();
												  nombre = "quicksortAleatorio.txt";
												  break;
												 }
									 }
									 break;
							//Mergesort
							case 4: if (this->cbDatos->SelectedIndex != -1)
									 switch (this->cbDatos->SelectedIndex) { 
										 case 0: {alg = new CAlgoritmoMergesortCreciente();
												  nombre = "mezclaCreciente.txt";
												  break;
												 }
										 case 1: {alg = new CAlgoritmoMergesortDecreciente();
												  nombre = "mezclaDecreciente.txt";
												  break;
												 }
										 case 2: {alg = new CAlgoritmoMergesortAleatorio();
												  nombre = "mezclaAleatorio.txt";
												  break;
												 }
									 }
									 break;
						}
				 
					//Comprobamos si se ha elegido generar el fichero GNUPlot
					 CSalidaGNUPlot* salida2 = NULL;
					 if (this->checkGNUPlot->Checked)
						 salida2 = new CSalidaGNUPlot (nombre);
			 
					 //Mostrar el tiempo total de las ejecuciones en formato HH:MM:SS
					 clock_t t1 = clock ();
					 medicion->LanzaPrueba(alg,salida,salida2);
					 clock_t t2 = clock ();
					 float tiempo =  (float(t2-t1) / CLOCKS_PER_SEC);

					 int horas = 0;
					 int minutos = 0;
					 float segundos = tiempo;
					 if (tiempo > 1){
						horas = int(tiempo / 3600);
						minutos = ((int(tiempo) % 3600) / 60);
						segundos = float (((int(tiempo) % 3600) % 60));
					 }
						std::string ttotal = "\r\n\r\n El tiempo total empleado ha sido de ";
						std::string cero = "0";
						std::string puntos = ":";
						tbResultados->AppendText(System::String(ttotal.c_str()).ToString()); 
						//Horas
						if (horas < 10)
							tbResultados->AppendText(System::String(cero.c_str()).ToString());	

						tbResultados->AppendText(horas.ToString());

						tbResultados->AppendText(System::String(puntos.c_str()).ToString());	

						//Minutos
						if (minutos < 10)
							tbResultados->AppendText(System::String(cero.c_str()).ToString());	

						tbResultados->AppendText(minutos.ToString());

						tbResultados->AppendText(System::String(puntos.c_str()).ToString());

						//Segundos
						if (segundos < 10)
							tbResultados->AppendText(System::String(cero.c_str()).ToString());
				
						tbResultados->AppendText(segundos.ToString());

					//Borrado de recursos
					 delete alg;
					 delete salida;
					 delete medicion;
					 if (this->checkGNUPlot->Checked)
						 delete salida2;
				}
			}
}

}