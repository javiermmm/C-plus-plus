#ifndef __CSALIDAWINDOWSFORMS_H
#define __CSALIDAWINDOWSFORMS_H

#include "Salida.h"

#include <string>
#include <fstream>
#include <vcclr.h>

//M�s informaci�n en la clase CSalida en el fichero "Salida.h"
class CSalidaWindowsForms : public CSalida {
public:
	//Constructor que inicializa el puntero atributo para que apunte al mismo textBox
	//en el que se mostrar�n los resultados
	CSalidaWindowsForms (gcroot<System::Windows::Forms::TextBox ^> tb);
	virtual  ~CSalidaWindowsForms ();
	virtual void  InitPrueba (const std::string &desc);
	virtual void  Muestra (int tam, float tiempo);
	virtual void  FinPrueba ();
protected:
	gcroot<System::Windows::Forms::TextBox ^> _tb; //TextBox de resultados
};

#endif